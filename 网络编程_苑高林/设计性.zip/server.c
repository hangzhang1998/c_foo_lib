#include<stdio.h>
#include<unistd.h>
#include<strings.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<stdlib.h>
#include<string.h>
#include<netdb.h>
#include<signal.h>
#include<sys/wait.h>
#define PORT 1234
#define BACKLOG 2
#define MAXCHARSIZE 1000
void process_client(int conectfd,struct sockaddr_in client);

int main(void)
{
int listenfd;
int connectfd;
struct sockaddr_in server;
struct sockaddr_in client;
int sin_size;
int opt=SO_REUSEADDR;
pid_t pid;
//int stat,i;
/*
/////////////////////////////
struct sigaction act,oldact;
act.sa_handler=SIG_IGN;
int i;
act.sa_flags=0;
if(sigaction(SIGCHLD,&act,&oldact)<0)  //第一种，信号处理
{
	printf("sigaction error.");
	exit(1);
}
//////////////////////////////
*/


/////////////////////////////
struct sigaction act;
act.sa_handler=SIG_IGN;
int i;
act.sa_flags=0;
sigemptyset(&act.sa_mask);
if(sigaction(SIGCHLD,&act,NULL)<0)  //第三种，信号补获
{
	printf("sigaction error.");
	exit(1);
}
//////////////////////////////

if((listenfd=socket(AF_INET,SOCK_STREAM,0))==-1)
{
perror("Create socket failed.");
exit(-1);
}

setsockopt(listenfd,SOL_SOCKET,SO_REUSEADDR,&opt,sizeof(opt));
bzero(&server,sizeof(server));
server.sin_family=AF_INET;
server.sin_port=htons(PORT);
server.sin_addr.s_addr=htonl(INADDR_ANY);

if(bind(listenfd,(struct sockaddr *)&server,sizeof(struct sockaddr))==-1)
{
perror("Bind error\n");
exit(-1);
}

if(listen(listenfd,BACKLOG)==-1)
{
perror("Listen error\n");
exit(-1);
}
sin_size=sizeof(struct sockaddr_in);
while(1){
if((connectfd=accept(listenfd,(struct sockaddr *)&client,&sin_size))==-1)
{
perror("Accept error\n");
exit(-1);
}
if((pid=fork())>0){/*父程序运行*/
/*
////////////////////////////
for(;(pid=wait(&stat))<0;)
{printf("no zombie");}
////////////////////////////
*/
close(connectfd);
continue;
}
else if(pid==0){/*子程序运行*/
close(listenfd);
process_client(connectfd,client);
exit(0);
}
else{
perror("Fork error\n");
exit(1);
}
}
close(listenfd);
}


void process_client(int connectfd,struct sockaddr_in client)
{
char recvbuf[MAXCHARSIZE];
char sendbuf[MAXCHARSIZE]; 
char client_name[MAXCHARSIZE];
int recvlen,i;
printf("You got a connetion from %s:%d\n",inet_ntoa(client.sin_addr),htons(client.sin_port));
send(connectfd,"Welcome to my server\n",22,0);
recvlen=recv(connectfd,client_name,MAXCHARSIZE,0);
if(recvlen==0){
close(connectfd);
printf("Client disconnected.\n");
return;
}
else if(recvlen<0){
close(connectfd);
printf("Connect broked.\n");
return;
}
client_name[recvlen]='\0';
printf("Client name is %s.\n",client_name);
while(recvlen=recv(connectfd,recvbuf,MAXCHARSIZE,0))
{
recvbuf[recvlen]='\0';
printf("Receive from client<%s> message:%s\n",client_name,recvbuf);
for(i=0;i<recvlen;i++)
{
sendbuf[i]=recvbuf[recvlen-i-1];
}
sendbuf[recvlen]='\0';
send(connectfd,sendbuf,strlen(sendbuf),0);
}/*while*/
printf("Client: %s disconnected.\n",client_name);
close(connectfd);
}
